var droppedElement = (event) => {
    event.preventDefault();
    var containerId = '#' + event.target.getAttribute("id");
    
    var imageTag = document.querySelector(productId);
    document.querySelector(containerId).append(imageTag);
}
var productId = '';
var elementDragStart = (event) => {    
    productId = "#" + event.target.getAttribute("id");
}

var elementDragOver = (event) => {
    event.preventDefault();
    
}