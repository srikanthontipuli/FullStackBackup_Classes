var singleProductTemplate;

document.addEventListener("DOMContentLoaded" ,() => {
    console.log($("#singleProductTemplate").html());
    singleProductTemplate = Handlebars.compile($("#singleProductTemplate").html());
})



var productDetails = [];



// var pdetails = get dta from server through AJAX;
var loadProductDetails = (pDetails, index) => {

    pDetails.index = index;
    $(".mainProductDetails").append(singleProductTemplate(pDetails));

    renderStarRatingBlock("#product_" + index, pDetails.rating);
}

var onLoadPage = () => {
    $(".mainProductDetails").html('');
    axios.get("/get/productList/details").then((result) => {
        productDetails = result.data.pDetails;
        for (var i = 0 ; i < productDetails.length; i++) {
           loadProductDetails(productDetails[i] , i);
        }
    }).catch((err) => {
        
    });

    // for (var i = 0 ; i < productDetails.length; i++) {
    //     loadProductDetails(productDetails[i] , i);
    // }
}
