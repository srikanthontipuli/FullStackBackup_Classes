var count = 0;
var loadBlocks = () => {
    count++;
    var msg = "Block " + count
    var divTag = document.createElement("div");
    divTag.setAttribute("class", 'block');
    divTag.innerText = msg;
    document.querySelector(".container").append(divTag);
    if (count == 5) {
        myWorker.terminate();
    } 
    if (count == 10) {
        startWorker();
    }
}
var myWorker;
var startWorker = () => {
    myWorker = new Worker("workers/dateWorkers.js");
    myWorker.onmessage = ((event) => {
        console.log(event.data);
        showDate(event.data)

        // myWorker.terminate();
        
    })
}

document.addEventListener("DOMContentLoaded", () => {
    setInterval(() => {
        loadBlocks();
    }, 1000 );  

    startWorker();
    
    

    
})


var showDate = (date) => {
    
    document.querySelector("span").innerHTML = date;
}