var getCurrentDate = () => {
    var cDate = new Date();
    var customDate = `${cDate.getDate()} - ${cDate.getMonth() + 1} - ${cDate.getFullYear()}   ${cDate.getHours()} : ${cDate.getMinutes()} : ${cDate.getSeconds()}`;
    postMessage(customDate);
    //document.querySelector("span").innerHTML = date;
}

setInterval(() => {
    getCurrentDate();
}, 1000)
