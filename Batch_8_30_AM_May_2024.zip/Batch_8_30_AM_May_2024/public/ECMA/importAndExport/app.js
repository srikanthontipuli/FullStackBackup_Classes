
// import  {getTotalSal, getTotalTax}  from "./salUtil.js";

 import * as salUtlobj from "./salUtil.js";


var readUserData = () => {
    var userData = {};
    userData.name = document.querySelector("#uname").value;
    userData.salary = parseInt(document.querySelector("#usal").value);
    
    userData.totalSal = salUtlobj.getTotalSal(userData.salary);

    document.querySelector("span").innerText = userData.totalSal;
}

document.addEventListener("DOMContentLoaded" , () => {
    document.querySelector("#getTaxBtn").addEventListener("click" , () => {
        readUserData();
    })
})