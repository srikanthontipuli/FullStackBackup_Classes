var getPfValue = (sal) => {
    var pf = 0 ; 
    pf = (sal * 14) / 100;
    return pf;
}

var getHraValue = (sal) => {
    var hra = 0 ; 
    hra = (sal * 25) / 100;
    return hra;
}

export var getTotalTax = (bsal) => {
    var totalSal = getTotalSal(bsal)
}

export var getTotalSal = (bsal) => {
    var totalSal = 0;
    var pf = getPfValue(bsal);
    var hra = getHraValue(bsal);
    totalSal = bsal + pf + hra;
    return totalSal;
}
