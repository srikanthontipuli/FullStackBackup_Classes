var userName;
var themeName;

var currentTime = new Date();


document.addEventListener("DOMContentLoaded", () => {
    if (sessionStorage.getItem("user_name") != null) {
        showWlcmMsg(sessionStorage.getItem("user_name"));
    }

    if (sessionStorage.getItem("theme_Name") != null) {
        applyTheme(sessionStorage.getItem("theme_Name") );
    }
});

var saveDetails = () => {
    userName = document.querySelector("#uname").value;
    sessionStorage.setItem("user_name", userName);
    showWlcmMsg(userName);
}

var showWlcmMsg = (userName) => {
    var msg = `Thanks for visiting page Mr. ${userName}`;
    document.querySelector("#wlcmBlock").innerHTML = msg;
    document.querySelector("#wlcmBlock").style.display = 'block';
}

var getTheme = () => {
    
    var themeName = $("#themeName").val();

    sessionStorage.setItem("theme_Name", themeName);
    
    applyTheme(themeName);
}

var applyTheme = (themeName) => {
    
    $("body").css("background-color", themeName);
}