
var mathUtilAPI = (() => {

    var count = 0;

  
    
    var mulValues = (a, b) => {
        count += 2;
        a = parseInt(a);
        b = parseInt(b);
        var result = a * b;
        return result;
    }
    var divValues = (a, b) => {
        count += 2;
        a = parseInt(a);
        b = parseInt(b);
        var result = a / b;
        return result;
    }
    
    var subValues = (a, b) => {
        count += 2;
        a = parseInt(a);
        b = parseInt(b);
        var result = a - b;
        return result;
    }
    
    return {
        addValues(a, b) {
            count += 2;
            a = parseInt(a);
            b = parseInt(b);
            var result = a + b;
            return result;
        },
        getMultiplication(a, b) {
            return mulValues(a, b);
        },
        getDivision(a1, a2) {
            return divValues(a1, a2);
        }
    };

})();
