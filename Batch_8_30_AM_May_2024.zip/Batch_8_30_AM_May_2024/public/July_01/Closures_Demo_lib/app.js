var count = 0;
var mathUtilAPI = 300;
var dojob = (type) => {
    count++;
    var a1 = $("#fval").val();
    var a2 = $("#sval").val();
    var result = 0;
    switch(type) {
        case 'add':
            result = mathUtilAPI.addValues(a1, a2);
            break;
        case 'mul':
            result = mathUtilAPI.getMultiplication(a1, a2);
            break;
        case 'div':
            result = mathUtilAPI.getDivision(a1, a2);
            break;
        case 'sub':
            result = subValues(a1, a2);
            break;
    }
    $("#rblock").text(type + ' -> ' + result);
    $("#countblock").text("count -> " + count);
}

var $= 90;
