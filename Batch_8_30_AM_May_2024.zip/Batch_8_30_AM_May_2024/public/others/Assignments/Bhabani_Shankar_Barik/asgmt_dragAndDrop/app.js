var productId = "";
var elementDragStart = (event) => {
  productId = event.target.getAttribute("id");
};
var elementDragOver = (event) => {
  event.preventDefault();
};
var droppedElement = (event) => {
  event.preventDefault();
  var containerId = "#" + event.target.getAttribute("id");
  var prdt = productId.split("_");
  if (prdt[0] === event.target.getAttribute("id")) {
    var imageTag = document.querySelector(`#${productId}`);
    document.querySelector(containerId).append(imageTag);
  } else {
    alert(`Drop ${prdt[0]} product under ${prdt[0]} section`);
  }
};
