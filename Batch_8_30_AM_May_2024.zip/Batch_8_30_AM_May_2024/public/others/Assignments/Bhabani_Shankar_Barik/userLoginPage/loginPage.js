document.addEventListener("DOMContentLoaded", function(){
    const loginForm = document.querySelector("#loginForm");
    const usernameInput = document.querySelector("#username");
    const passwordInput = document.querySelector("#password");
    const rememberMeCheckbox = document.querySelector("#rememberMe");
    const loginMessage = document.querySelector("#loginMessage");

    //check for saved login details
    // if(localStorage.username && localStorage.password && localStorage.rememberMe){
    //     usernameInput.value = localStorage.username;
    //     passwordInput.value = localStorage.password;
    //     rememberMeCheckbox.checked = true;
    // }


    // function to check and fill saved login details
    function fillSavedLoginDetails(){
        if(localStorage.username && localStorage.password && localStorage.rememberMe){
            usernameInput.value = localStorage.username;
            passwordInput.value = localStorage.password;
            rememberMeCheckbox.checked = true;
        }
    }

    //check and fill saved login details on page load
    fillSavedLoginDetails();


    //save login details on form submission
    loginForm.addEventListener("submit", function(event){
        event.preventDefault(); // prevent from submission

        //check if "remember this login" is checked
        if (rememberMeCheckbox.checked){
            localStorage.username = usernameInput.value;
            localStorage.password = passwordInput.value;
            localStorage.rememberMe = true;
        } else {
            localStorage.removeItem("username");
            localStorage.removeItem("password");
            localStorage.removeItem("rememberMe");
        }


        // clear input fields
        usernameInput.value = "";
        passwordInput.value = "";
        rememberMeCheckbox.checked = false;
        

        // Display login success message
        loginMessage.textContent = 'Login Successful!'
        

    });

    // Event listener for when username or password inputs are clicked 
    usernameInput.addEventListener('click', fillSavedLoginDetails)
    passwordInput.addEventListener('click', fillSavedLoginDetails)
});