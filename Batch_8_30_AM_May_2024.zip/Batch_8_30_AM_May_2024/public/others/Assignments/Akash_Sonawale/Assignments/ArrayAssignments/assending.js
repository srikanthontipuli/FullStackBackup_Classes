let numbers = [5, 3, 8, 1, 2];


numbers.sort((a, b) => a - b);

console.log(numbers); 
