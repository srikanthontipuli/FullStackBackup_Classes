let array = [232,334,6,7,7878,999];
array.sort((a,b)=>b-a);
console.log(array)