document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); 
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('rememberMe').checked;
    

    if (username && password) {
        alert('Login successfull!\nUsername: ' + username + '\nRemember Me: ' + (rememberMe ? 'Yes' : 'No'));
    } else {
        alert('Please enter both username and password.');
    }
});