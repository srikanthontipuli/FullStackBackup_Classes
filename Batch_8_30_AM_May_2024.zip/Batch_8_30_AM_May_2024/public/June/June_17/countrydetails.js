var countryDetails = [
    {
        id: 'c_01',
        name: 'India',
    },
    {
        id: 'c_12',
        name: 'Chaina'
    }
    . . . .  
];

var stateDetails = {
    'c_01': [
        {
            scode: 's_12',
            name: 'TEst'
        },
        {
            scode: 's_15',
            name: 'Sample'
        }
    ],
    c_12: [
        {
            scode: 's_17',
            name: 'abc'
        }
    ]
}

var districtdetails = {
    's_12': ["abc", sample, testing],
    "s_15": ["new", "old", "abc"]
}