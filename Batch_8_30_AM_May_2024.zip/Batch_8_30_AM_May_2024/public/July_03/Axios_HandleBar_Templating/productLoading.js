var singleProductTemplate;

document.addEventListener("DOMContentLoaded" ,() => {
    console.log($("#singleProductTemplate").html());
    singleProductTemplate = Handlebars.compile($("#singleProductTemplate").html());
})



var productDetails = [];



// var pdetails = get dta from server through AJAX;
var loadProductDetails = (pDetails, index) => {

    pDetails.index = index;
    $(".mainProductDetails").append(singleProductTemplate(pDetails));

    renderStarRatingBlock("#product_" + index, pDetails.rating);
}

var onLoadPage = () => {
    $(".loadingBlock").show();
    $(".mainProductDetails").html('');
    axios.get("http://localhost:8081/get/productList/details").then((result) => {
        $(".loadingBlock").hide();
        productDetails = result.data.pDetails;
        for (var i = 0 ; i < productDetails.length; i++) {
           loadProductDetails(productDetails[i] , i);
        }
    }).catch((err) => {
        $(".errorBlock").show();
        $(".loadingBlock").hide();
    });

    // for (var i = 0 ; i < productDetails.length; i++) {
    //     loadProductDetails(productDetails[i] , i);
    // }
}
